#ifndef MAIN_H
#define MAIN_H


class main
{
    public:
        main();
        virtual ~main();

    protected:

    private:
};

#endif // MAIN_H
