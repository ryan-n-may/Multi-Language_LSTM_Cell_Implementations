#!/usr/bin/env ruby
=begin
Created: 	14/09/2023.
Version: 	1.0.0
=end
require 'numo/narray'
include Numo
=begin 
Dictionary
=end
class DICTIONARY < ENCODER
	def init(string, x_dim)
		@x_dim = x_dim
		@frequencyHash = wordFrequency(string)
		@stringToEncoding, @encodingToString = hotEncodeVocabulary(@frequencyHash, x_dim)
	end
	def getFrequencyHash()
		return @frequencyHash
	end
	def getEncodingHashs()
		return @stringToEncoding, @encodingToString
	end
	def wordFrequency(words)
		if words.is_a?(String)
			words = words.split
		end
		frequency = {}
		entries = 0
		for i in 0...words.length()
			if frequency[words[i]] == nil
				frequency[words[i]] = 1
				entries += 1
			else
				frequency[words[i]] = frequency[words[i]] + 1
			end
		end
		return frequency.sort_by {|k, v| v}.reverse
	end
	def hotEncodeVocabulary(hash, maxEntries)
		stringToEncoding = {}
		encodingToString = {}
		binary = 0b1
		hash.each do |key, value|
			stringToEncoding["#{key}"] = binary
			encodingToString[binary] = "#{key}"
			binary = binary << 1
			if (binary) == (0b1 << maxEntries)
				break;
			end
		end
		return stringToEncoding, encodingToString
	end
	def readFileDataArray(fileDataArray, fileIndex, start, input_len, predict_len)
		fileWordArray = (fileDataArray[fileIndex]).split
		return fileWordArray[start, input_len], fileWordArray[(start+predict_len), (input_len)]
	end
	def encodeArray(wordArray, hash=@stringToEncoding)
		if wordArray.instance_of? String
			wordArray = wordArray.split()
		end 
		array = Int32.zeros(wordArray.length(), @x_dim)
		for i in 0...wordArray.length()
			word = wordArray[i]
			encoding = hash[word]
			if encoding != nil
				binaryArray = binaryToArray(encoding, @x_dim)
				array[i, true] = binaryArray
			end
		end
		return array
	end
	def binaryToArray(binary, x_dim)
		binaryFormatted = ((0b1 << (x_dim+1) ^ binary*2)).to_s(2)[1, x_dim]
		binaryArray = DFloat.zeros(1, x_dim)
		binaryArray = binaryFormatted.split("").map(&:to_i)
		return binaryArray
	end
	def arrayToBinary(array)
		binaryString = array.to_a.join("")
		binary = binaryString.to_i(2)
		return binary
	end
	def decodeArray(encodedArray, hash=@encodingToString)
		output = ""
		for i in 0...encodedArray.shape()[0]
			decodedWord = hash[arrayToBinary(encodedArray[i, true])]
			if decodedWord != nil
				output += decodedWord + " "
			else 
				output += "@ "
			end
		end
		return output
	end
	def decodeArrayByMaximum(encodedArray, hash=@encodingToString)
		output = ""
		for i in 0..encodedArray.shape()[0]-1
			if encodedArray[i, true].to_a.max != 0
				max_element = encodedArray[i, true].to_a.each_with_index.max[1]
				encodedArrayBW = Int32.zeros(encodedArray[i, true].shape())
				encodedArrayBW[max_element] = 1
				decodedWord = hash[arrayToBinary(encodedArrayBW)]
				if decodedWord != nil
					output += decodedWord + " "
				else 
					output += "@ "
				end
			else 
				output += "$ "
			end
		end
		return output
	end
	def viewHash(hash)
		puts "key -> value"
		entries = 0
		hash.each do |key, value|
			puts key.to_s + " -> " + value.to_s
			entries += 1
		end
		puts "Entires in hash: " + entries.to_s
	end
end
