#!/usr/bin/env ruby
=begin
██╗░░░░░░██████╗████████╗███╗░░░███╗
██║░░░░░██╔════╝╚══██╔══╝████╗░████║
██║░░░░░╚█████╗░░░░██║░░░██╔████╔██║
██║░░░░░░╚═══██╗░░░██║░░░██║╚██╔╝██║
███████╗██████╔╝░░░██║░░░██║░╚═╝░██║
╚══════╝╚═════╝░░░░╚═╝░░░╚═╝░░░░░╚═╝
Created: 	14/09/2023.
Version: 	1.0.0
Author: 	Ryan May
This is a text generator LSTM developed in Ruby. 
In this project I gain more of an understanding of the training and creation of LSTM networks.
This LSTM network utilises the Numo::Narray library to calculate cell states and the cell network.
Expansion on this project will be utilised in my Honours project. 
=end
require 'matrix' 		# https://www.rubyguides.com/2019/01/ruby-matrix/
require 'numo/narray'
include Numo
=begin 
███████╗███╗░░██╗░█████╗░░█████╗░██████╗░███████╗██████╗░
██╔════╝████╗░██║██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔══██╗
█████╗░░██╔██╗██║██║░░╚═╝██║░░██║██║░░██║█████╗░░██████╔╝
██╔══╝░░██║╚████║██║░░██╗██║░░██║██║░░██║██╔══╝░░██╔══██╗
███████╗██║░╚███║╚█████╔╝╚█████╔╝██████╔╝███████╗██║░░██║
╚══════╝╚═╝░░╚══╝░╚════╝░░╚════╝░╚═════╝░╚══════╝╚═╝░░╚═╝
The encoder class is used to translate input characters and sentances into one-hot encoded vectors. 
Additionally, the encoder class contains functions to handle file reading, regex filtering, and conversions
between 'Matrix' and 'NArray' types.
=end
class ENCODER
	def init(charmatrix = nil)
		if charmatrix == nil
			@Length = 56
			@SelectionMatrix = Matrix.build(1,56) {0} # 1 row 32 columns
			@CharMatrix = Array['.',',',"\s",'!',
								'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
								'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
		else 
			@Length = charmatrix.length()
			@SelectionMatrix = Matrix.build(1, charmatrix.length()) { 0 }
			@CharMatrix = charmatrix
		end
	end
	def matrixToNArray(matrix)
		nArray = DFloat[*matrix.to_a]
		return nArray
	end
	def nArrayToMatrix(nArray)
		#puts nArray.to_a.map(&:inspect)
		matrix = Matrix[*nArray.to_a]
		#puts matrix.to_a.map(&:inspect)
		return matrix
	end
	def listFilesInDirectory(path)
		fileNameArray = Dir.entries(path).reject {|f| File.directory?(f) || f[0].include?('.')}
		return fileNameArray
	end
	def readPlaintextFilesInDirectory(path)
		fileDataArray = Array.new(0) { "" }
		# Get names of all files in a folder. 
		fileNameArray = Dir.entries(path).reject {|f| File.directory?(f) || f[0].include?('.')}
		# itterate through all files in Array
		for index in 0...fileNameArray.length()
			puts "reading file " + path + "/" + fileNameArray[index]
			fileData = readPlaintextfile(path + "/" + fileNameArray[index])
			fileDataArray = fileDataArray << fileData
		end
		return fileDataArray
	end
	def readFileDataArray(fileDataArray, index, start, input_len, predict_len)
		combination = hotEncodeSentance(filter(fileDataArray[index])[start,predict_len+input_len])
		return combination
	end
	def readPlaintextfile(fileName)
		file = File.open(fileName)
		file_data = file.read
		file.close
		return file_data
	end
	def filter(sentance, regex=nil)
		if regex == nil
			sentance = sentance.gsub(/[^A-Za-z\., ]/, '')
		else 
			sentance = sentance.gsub(regex, '')
		end
		return sentance
	end
	def hotEncodeSentance(sentance)
		letters = sentance.split(//)
		matrix = Matrix.build(0, 0){0}
		for index in 0...letters.length()
			charvector = hotEncodeCharacter(letters[index])
			if charvector != nil
				matrix = Matrix.rows(matrix.to_a << charvector.to_a)
			end
		end
		return matrix
	end
	def hotDecodeSentance(matrix)
		sentance = ""
		for index in 0...matrix.row_count()
			charvector = matrix.row(index)
			char = hotDecodeCharacter(charvector)
			sentance = sentance + char 
		end
		return sentance
	end
	def hotEncodeCharacter(char)
		# reset selection matrix
		@SelectionMatrix = Matrix.build(1,@Length) {0}
		index = @CharMatrix.index char
		@SelectionMatrix[0,index] = 1
		return @SelectionMatrix.row(0)
	end
	def hotDecodeCharacter(vector)
		# convert vector to array so we can search for the up bit
		vectorArray = vector.to_a
		index = vectorArray.each_with_index.max[1] 
		if index != nil
			return @CharMatrix[index]
		else 
			return '@'
		end
	end
	def stringDifferencePercent(a, b)
	  longer = [a.size, b.size].max
	  same = a.each_char.zip(b.each_char).count { |a,b| a == b }
	  similarity = (longer - same) / a.size.to_f
	  return similarity
	end
end
