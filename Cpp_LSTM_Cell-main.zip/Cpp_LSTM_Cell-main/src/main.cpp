#include "main.h"
#include "Cell.h"
#include "Network.h"
#include "single_cell_test.h"
#include "network_test.h"
#include <iostream>
#include <math.h>

int main()
{
    //single_cell_test test1 = single_cell_test();
    //test1.test();
    network_test test2 = network_test();
    test2.test();
}
