# One-hot-dictionary in Ruby
This Ruby gem creates an encoder and dictionary class that are capable of one-hot encoding characters and strings from input sentances. 

![ruby](https://img.shields.io/badge/Ruby-CC342D?style=for-the-badge&logo=ruby&logoColor=white) 

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Usage
### Installation 
```ruby
gem install one-hot-dictionary
require 'one-hot-dictionary'
```
* requires Numo::NArrray https://github.com/ruby-numo/numo-narray
### Documentation
```ruby
@dict = DICTIONARY.new
```
#### initialisation
```ruby
@dict.init(input_message [string], x_dim [integer])
```
* This method generates a dictionary encoding of size x_dim.
* If words in the input_message outnumber x_dim, words are prioritised by the highest frequency.
#### Get encoding and decoding hash 
```ruby
@dict.getEncodingHashs() -> @stringToEncoding, @encodingToString [hash]
```
* `@stringToEncoding` maps dictionary words [string] to binary [Numo::NArray].
* `@encodingToString` maps binary [Numo::NArray] to words [string]
#### Get frequency hash
```ruby
@dict.getFrequencyHash() -> @frequencyHash [hash]
```
* `@frequencyHash` maps all words of the `input_message` to their occurances. 
#### Word frequency
```ruby
@dict.wordFrequency(input_message [string or []string]) -> frequency [hash]
```
* Converts input string or array of strings into hash of occurance counts, the counts are sorted in descending order.
#### Hot encode vocabulary
```ruby
@dict.hotEncodeVocabulary(frequency [hash], maxEntries [integer]) -> stringToEncoding, encodingToString [hash]
```
* Encodes vocabulary words from frequency hash. Limits vocabulary by `maxEntries`.
* ie: `dog` == `[0,0,0,0,1,0,0]` if `maxEntries = 8` and "dog" is the 3rd most frequent words.
#### Read file data array
```ruby
@dict.readFileDataArray(fileDataArray [[]string], fileIndex, start, input_len, predict_len [integer]) -> [string], [string]
```
* fileDataArray is an array of strings.
* first sub-string is: fileDataArray[fileIndex][start, input_len]
* second sub-string is: fileDataArray[fileIndex][start+predict_len, input_len+predict_len]
#### Encode array 
```ruby
@dict.encodeArray(wordArray [string or []string], hash=@stringToEncoding) -> array [Numo:NArray]
```
* converts word array [strings] to encoded array via hash.
#### Decode array
```ruby
@dict.decodeArray(encodedArrray [Numo::NArray], hash=@encodingToString) -> output [string]
```
* If an array doesn't have a decoding, "@" is appened to the string.
#### Decode array by maximum 
```ruby
@dict.decodeArrayByMaximum(encodedArrray [Numo::NArray], hash=@encodingToString) -> output [string]
```
* If hot encoded array is not binary, max elment is considered the key index.
* `[0.3,0.1,0.2,0.7] == [0,0,0,1]`
#### Binary to array
```ruby
@dict.binaryToArray(binary, x_dim [integer]) -> binaryArray [Numo::NArray]
```
* converts input integer to binary array of fixed length `x_dim`
#### Array to binary 
```ruby
@dict.arrayToBinary(array [Numo::NArray]) -> binary [integer]
```
#### View hash
```ruby
@dict.viewHash([hash])
```

